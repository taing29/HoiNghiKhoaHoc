﻿using HoiNghiKhoaHoc.Models.ViewModels;
using HoiNghiKhoaHoc.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace HoiNghiKhoaHoc.Controllers
{
    public class ConferencesController : Controller
    {
        private readonly IConferenceRepository _conferenceRepository;
        private readonly ICategoryRepository _categoryRepository;

        public ConferencesController(IConferenceRepository conferenceRepository, ICategoryRepository categoryRepository)
        {
            _conferenceRepository = conferenceRepository;
            _categoryRepository = categoryRepository;
        }

        // Hiển thị tất cả hội nghị (Index vẫn giữ nguyên)
        public async Task<IActionResult> Index()
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "Conferences", new { area = "Admin" });
            }
            var conferences = await _conferenceRepository.GetAllConferencesAsync();
            return View(conferences);
        }

        public async Task<IActionResult> Upcoming()
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "Conferences", new { area = "Admin" });
            }
            var upcoming = await _conferenceRepository.GetUpcomingConferencesAsync();
            return View(upcoming);
        }

        public async Task<IActionResult> Past()
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "Conferences", new { area = "Admin" });
            }
            var past = await _conferenceRepository.GetPastConferencesAsync();
            return View(past);
        }

        public async Task<IActionResult> International()
        {
            if (User.IsInRole("Admin"))
            {
                return RedirectToAction("Index", "Conferences", new { area = "Admin" });
            }
            var international = await _conferenceRepository.GetInternationalConferencesAsync();
            return View(international);
        }

        public async Task<IActionResult> Details(int id)
        {
            var conference = await _conferenceRepository.GetConferenceByIdAsync(id);
            if (conference == null)
            {
                return NotFound();
            }

            var relatedConferences = await _conferenceRepository.GetConferenceByIdCategory(conference);

            var viewModel = new ConferenceDetailViewModel
            {
                CurrentConference = conference,
                RelatedConferences = relatedConferences
            };

            return View(viewModel);
        }
    }
}