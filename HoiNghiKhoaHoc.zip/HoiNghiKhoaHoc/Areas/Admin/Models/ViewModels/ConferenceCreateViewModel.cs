﻿namespace HoiNghiKhoaHoc.Areas.Admin.Models.ViewModels
{
	public class ConferenceCreateViewModel
	{
		public string Title { get; set; }
		public string? Description { get; set; }
		public string? Content { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime EndDate { get; set; }
		public string Location { get; set; }
		public string Organizer { get; set; }
		public bool IsActive { get; set; } = true;
		public int CategoryId { get; set; }

		public IFormFile? BannerImage { get; set; }
	}
}
