﻿namespace HoiNghiKhoaHoc.Areas.Admin.Models
{
    public static class SD
    {
        public const string Role_Admin = "Admin";
        public const string Role_User = "User";
    }
}
